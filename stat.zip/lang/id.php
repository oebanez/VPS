<?php

// bahasa edited by Suhendra Wahyu
// boleh di copy namun hargai karya orang lain
$L['summary'] = 'Ringkasan';
$L['hours'] = 'Jam';
$L['days'] = 'Hari';
$L['months'] = 'Bulan';

// main table headers
$L['Summary'] = 'Ringkasan';
$L['Top 10 days'] = '10 Hari Terakhir';
$L['Last 24 hours'] = '24 Jam Terakhir';
$L['Last 30 days'] = '30 Hari Terakhir';
$L['Last 12 months'] = '12 Bulan Terakhir';

// traffic table columns
$L['In'] = 'Data Download';
$L['Out'] = 'Data Upload';
$L['Total'] = 'Total Data';

// summary rows
$L['This hour'] = '1 Jam terakhir';
$L['This day'] = 'Hari ini';
$L['This month'] = 'Bulan ini';
$L['All time'] = 'Total';

// graph text
$L['Traffic data for'] = 'Trafik Lalu Lintas Data LastOebanez Network Server';
$L['bytes in'] = 'bytes in';
$L['bytes out'] = 'bytes out';

// date formats
$L['datefmt_days'] = '%d %B';
$L['datefmt_days_img'] = '%d';
$L['datefmt_months'] = '%B %Y';
$L['datefmt_months_img'] = '%b';
$L['datefmt_hours'] = '%l%P';
$L['datefmt_hours_img'] = '%l';
$L['datefmt_top'] = '%d %B %Y';
